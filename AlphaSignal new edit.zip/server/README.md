# Server

Backend will be added in a future version. Currently the app is client-only with direct API calls to free public endpoints (DefiLlama, CoinGecko, GeckoTerminal, CryptoPanic).
