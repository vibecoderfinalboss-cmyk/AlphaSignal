/**
 * Alpha Signal — API Service Layer
 * 
 * All external API calls centralized here.
 * Every API used is FREE with no key required (except CryptoPanic which needs a free key).
 * 
 * APIs integrated:
 * 1. DefiLlama  — Protocol discovery, TVL, funding rounds, tokenless protocols
 * 2. CoinGecko  — Token prices, trending, categories, market data
 * 3. GeckoTerminal — On-chain DEX trending pools per chain
 * 4. CryptoPanic — Crypto news with sentiment (needs free API key)
 */

// ═══ CACHE ═══
const cache = {};
const CACHE_TTL = 5 * 60 * 1000; // 5 minutes

async function cachedFetch(key, url, transform, ttl = CACHE_TTL) {
  const now = Date.now();
  if (cache[key] && now - cache[key].ts < ttl) return cache[key].data;
  try {
    const res = await fetch(url);
    if (!res.ok) throw new Error(`${res.status}`);
    const raw = await res.json();
    const data = transform ? transform(raw) : raw;
    cache[key] = { data, ts: now };
    return data;
  } catch (err) {
    console.warn(`API fetch failed [${key}]:`, err.message);
    if (cache[key]) return cache[key].data; // return stale data
    return null;
  }
}

// ═══ 1. DEFILLAMA — Protocol Discovery ═══
// Docs: https://defillama.com/docs/api
// No API key needed. No published rate limit.

const LLAMA = "https://api.llama.fi";

/** Get all protocols with TVL — the master list */
export async function getProtocols() {
  return cachedFetch("protocols", `${LLAMA}/protocols`, (raw) =>
    raw
      .filter(p => p.tvl > 1_000_000) // only >$1M TVL
      .map(p => ({
        name: p.name,
        slug: p.slug,
        tvl: p.tvl,
        chain: p.chain,
        chains: p.chains || [],
        category: p.category,
        symbol: p.symbol || null,
        logo: p.logo,
        url: p.url,
        tokenless: !p.symbol, // no token = potential airdrop
      }))
      .sort((a, b) => b.tvl - a.tvl),
    10 * 60 * 1000 // 10 min cache
  );
}

/** Get tokenless protocols — prime airdrop candidates */
export async function getTokenlessProtocols() {
  const all = await getProtocols();
  if (!all) return [];
  return all.filter(p => p.tokenless).slice(0, 50);
}

/** Get recent funding raises — high funding + no token = airdrop signal */
export async function getRaises() {
  return cachedFetch("raises", `${LLAMA}/raises`, (raw) =>
    (raw?.raises || [])
      .filter(r => r.amount >= 5_000_000) // $5M+ raises only
      .sort((a, b) => b.date - a.date)
      .slice(0, 30)
      .map(r => ({
        name: r.name,
        amount: r.amount,
        round: r.round,
        sector: r.sector,
        leadInvestors: r.leadInvestors || [],
        date: new Date(r.date * 1000).toLocaleDateString(),
        chains: r.chains || [],
      })),
    30 * 60 * 1000 // 30 min cache
  );
}

/** Get yield pools — enrich farm tasks with real APY data */
export async function getTopYields(chain) {
  const key = `yields_${chain || "all"}`;
  return cachedFetch(key, `https://yields.llama.fi/pools`, (raw) => {
    let pools = raw?.data || [];
    if (chain) pools = pools.filter(p => p.chain?.toLowerCase() === chain.toLowerCase());
    return pools
      .filter(p => p.tvlUsd > 500_000 && p.apy > 0)
      .sort((a, b) => b.apy - a.apy)
      .slice(0, 20)
      .map(p => ({
        pool: p.pool,
        project: p.project,
        chain: p.chain,
        symbol: p.symbol,
        tvl: p.tvlUsd,
        apy: Math.round(p.apy * 100) / 100,
      }));
  }, 10 * 60 * 1000);
}

// ═══ 2. COINGECKO — Market Data ═══
// Free tier: 30 calls/min, no key needed for /api/v3
// Docs: https://docs.coingecko.com

const GECKO = "https://api.coingecko.com/api/v3";

/** Get trending coins — powers "what's hot" in Feed */
export async function getTrending() {
  return cachedFetch("trending", `${GECKO}/search/trending`, (raw) =>
    (raw?.coins || []).map(c => ({
      id: c.item.id,
      name: c.item.name,
      symbol: c.item.symbol,
      marketCapRank: c.item.market_cap_rank,
      thumb: c.item.thumb,
      priceBtc: c.item.price_btc,
      score: c.item.score,
    }))
  );
}

/** Get category performance — narrative detection */
export async function getCategories() {
  return cachedFetch("categories", `${GECKO}/coins/categories?order=market_cap_change_24h_desc`, (raw) =>
    (raw || []).slice(0, 15).map(c => ({
      id: c.id,
      name: c.name,
      marketCap: c.market_cap,
      marketCapChange24h: Math.round((c.market_cap_change_24h || 0) * 100) / 100,
      volume24h: c.volume_24h,
      topCoins: (c.top_3_coins || []),
    }))
  );
}

/** Get global market data — BTC price, dominance, total market cap */
export async function getGlobalMarket() {
  return cachedFetch("global", `${GECKO}/global`, (raw) => {
    const d = raw?.data;
    if (!d) return null;
    return {
      totalMarketCap: d.total_market_cap?.usd,
      totalVolume24h: d.total_volume?.usd,
      btcDominance: Math.round((d.market_cap_percentage?.btc || 0) * 10) / 10,
      ethDominance: Math.round((d.market_cap_percentage?.eth || 0) * 10) / 10,
      activeCryptos: d.active_cryptocurrencies,
      marketCapChange24h: Math.round((d.market_cap_change_percentage_24h_usd || 0) * 100) / 100,
    };
  });
}

/** Get simple prices for a list of coin IDs */
export async function getPrices(ids) {
  const idStr = ids.join(",");
  return cachedFetch(`prices_${idStr}`,
    `${GECKO}/simple/price?ids=${idStr}&vs_currencies=usd&include_24hr_change=true`,
    (raw) => raw
  );
}


// ═══ 3. GECKOTERMINAL — On-Chain DEX Data ═══
// 100% free, no key, 30 calls/min
// Docs: https://apiguide.geckoterminal.com

const GTERM = "https://api.geckoterminal.com/api/v2";

const CHAIN_MAP = {
  ethereum: "eth", base: "base", arbitrum: "arbitrum",
  megaeth: "megaeth", optimism: "optimism",
};

/** Get trending pools on a specific chain */
export async function getTrendingPools(chain = "eth") {
  return cachedFetch(`tpools_${chain}`, `${GTERM}/networks/${chain}/trending_pools`, (raw) =>
    (raw?.data || []).slice(0, 10).map(p => ({
      name: p.attributes?.name,
      address: p.attributes?.address,
      dex: p.attributes?.dex_id,
      volume24h: parseFloat(p.attributes?.volume_usd?.h24 || 0),
      priceChangeH24: parseFloat(p.attributes?.price_change_percentage?.h24 || 0),
      baseToken: p.relationships?.base_token?.data?.id,
    }))
  );
}

/** Get newly created pools — discover new activity */
export async function getNewPools(chain = "eth") {
  return cachedFetch(`npools_${chain}`, `${GTERM}/networks/${chain}/new_pools`, (raw) =>
    (raw?.data || []).slice(0, 10).map(p => ({
      name: p.attributes?.name,
      createdAt: p.attributes?.pool_created_at,
      dex: p.attributes?.dex_id,
      baseToken: p.relationships?.base_token?.data?.id,
    }))
  );
}


// ═══ 4. CRYPTOPANIC — News Feed ═══
// Free tier: 5 req/min. Requires free API key.
// Sign up: https://cryptopanic.com/developers/api/
// If no key is set, falls back to mock data.

const CPANIC_KEY = "c65839b0aeca610c865fceaf0665a2d26c242f7e"; // User sets this — free signup at cryptopanic.com

/** Get trending crypto news */
export async function getNews(filter = "hot") {
  if (!CPANIC_KEY) return getMockNews(); // Fallback when no key
  return cachedFetch(`news_${filter}`,
    `https://cryptopanic.com/api/v1/posts/?auth_token=${CPANIC_KEY}&filter=${filter}&kind=news&public=true`,
    (raw) => (raw?.results || []).slice(0, 12).map(n => ({
      id: n.id,
      title: n.title,
      source: n.source?.title || "Unknown",
      url: n.url,
      publishedAt: n.published_at,
      sentiment: n.votes?.positive > n.votes?.negative ? "bullish" : n.votes?.negative > n.votes?.positive ? "bearish" : "neutral",
      currencies: (n.currencies || []).map(c => c.code),
    })),
    3 * 60 * 1000 // 3 min cache for news
  );
}

/** Mock news fallback when no CryptoPanic key is configured */
function getMockNews() {
  return [
    { id: 1, title: "Connect CryptoPanic API for live news", source: "Alpha Signal", url: "#", publishedAt: new Date().toISOString(), sentiment: "neutral", currencies: [] },
    { id: 2, title: "Get your free key at cryptopanic.com/developers/api", source: "Setup Guide", url: "https://cryptopanic.com/developers/api/", publishedAt: new Date().toISOString(), sentiment: "neutral", currencies: [] },
  ];
}


// ═══ 5. COMPOSITE FUNCTIONS — Combine APIs for Alpha Signal features ═══

/** 
 * Build the Feed tab data — combines news, trending coins, and hot categories
 * This is what shows in the 📰 Feed tab
 */
export async function buildFeed() {
  const [news, trending, categories] = await Promise.all([
    getNews(),
    getTrending(),
    getCategories(),
  ]);

  const items = [];

  // News items
  if (news) {
    news.slice(0, 6).forEach(n => {
      items.push({
        type: "news",
        id: `n_${n.id}`,
        headline: n.title,
        source: n.source,
        url: n.url,
        time: getTimeAgo(n.publishedAt),
        sentiment: n.sentiment,
        niche: n.currencies?.[0] || "Crypto",
        color: n.sentiment === "bullish" ? "#34C759" : n.sentiment === "bearish" ? "#FF4757" : "#6B7280",
      });
    });
  }

  // Trending coins
  if (trending) {
    trending.slice(0, 3).forEach(t => {
      items.push({
        type: "trending",
        id: `t_${t.id}`,
        headline: `${t.name} (${t.symbol.toUpperCase()}) is trending`,
        source: "CoinGecko Trending",
        url: `https://www.coingecko.com/en/coins/${t.id}`,
        time: "now",
        sentiment: "bullish",
        niche: "Trending",
        color: "#FF8C42",
        rank: t.marketCapRank,
      });
    });
  }

  // Hot categories
  if (categories) {
    categories.filter(c => Math.abs(c.marketCapChange24h) > 3).slice(0, 2).forEach(c => {
      const up = c.marketCapChange24h > 0;
      items.push({
        type: "category",
        id: `c_${c.id}`,
        headline: `${c.name} ${up ? "up" : "down"} ${Math.abs(c.marketCapChange24h)}% in 24h`,
        source: "Market Data",
        url: `https://www.coingecko.com/en/categories/${c.id}`,
        time: "24h",
        sentiment: up ? "bullish" : "bearish",
        niche: c.name,
        color: up ? "#34C759" : "#FF4757",
      });
    });
  }

  return items;
}

/**
 * Build airdrop discovery data — tokenless protocols + recent raises
 * This powers the "Discover" section in the Farm tab
 */
export async function buildAirdropDiscovery() {
  const [tokenless, raises] = await Promise.all([
    getTokenlessProtocols(),
    getRaises(),
  ]);

  const opportunities = [];

  if (tokenless) {
    tokenless.slice(0, 15).forEach(p => {
      // Cross-reference with raises for extra signal
      const raise = raises?.find(r => r.name.toLowerCase() === p.name.toLowerCase());
      opportunities.push({
        id: `d_${p.slug}`,
        name: p.name,
        chain: p.chains?.[0] || p.chain || "Multi-chain",
        category: p.category,
        tvl: p.tvl,
        logo: p.logo,
        url: p.url,
        funding: raise?.amount || null,
        fundingRound: raise?.round || null,
        investors: raise?.leadInvestors || [],
        score: calculateOpportunityScore(p, raise),
      });
    });
  }

  return opportunities.sort((a, b) => b.score - a.score);
}

/** Score an airdrop opportunity (0-100) */
function calculateOpportunityScore(protocol, raise) {
  let score = 0;
  // TVL weight (25%)
  if (protocol.tvl > 100_000_000) score += 25;
  else if (protocol.tvl > 10_000_000) score += 18;
  else if (protocol.tvl > 1_000_000) score += 10;
  // Funding weight (25%)
  if (raise) {
    if (raise.amount > 50_000_000) score += 25;
    else if (raise.amount > 10_000_000) score += 18;
    else score += 10;
  }
  // Chain diversity (15%)
  if (protocol.chains?.length > 3) score += 15;
  else if (protocol.chains?.length > 1) score += 10;
  // Category bonus (10%)
  const hotCategories = ["dexes", "lending", "bridge", "restaking", "liquid staking"];
  if (hotCategories.includes(protocol.category?.toLowerCase())) score += 10;
  // Base score for being tokenless (25%)
  score += 25;
  return Math.min(score, 100);
}

/**
 * Get market summary for dashboard header
 */
export async function getMarketSummary() {
  const global = await getGlobalMarket();
  if (!global) return null;
  return {
    btcDominance: global.btcDominance,
    marketCapChange: global.marketCapChange24h,
    sentiment: global.marketCapChange24h > 1 ? "🟢" : global.marketCapChange24h < -1 ? "🔴" : "🟡",
  };
}


// ═══ UTILITIES ═══

function getTimeAgo(dateStr) {
  if (!dateStr) return "";
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `${mins}m`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h`;
  return `${Math.floor(hrs / 24)}d`;
}

/** Format large numbers */
export function formatNum(n) {
  if (!n) return "—";
  if (n >= 1e9) return `$${(n / 1e9).toFixed(1)}B`;
  if (n >= 1e6) return `$${(n / 1e6).toFixed(1)}M`;
  if (n >= 1e3) return `$${(n / 1e3).toFixed(0)}K`;
  return `$${n.toFixed(0)}`;
}
